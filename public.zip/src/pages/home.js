import React from 'react';

import HeaderSection from '../components/header/HeaderSection';
import FooterSection from '../components/footer/FooterSection';
import BodySection from '../components/body/BodySection';

export default class Home extends React.Component {
    render() {
        let items = this.props.items || [];
        return  <React.Fragment>
                    <HeaderSection />
                    <BodySection items={items} />
                    <FooterSection />
                </React.Fragment>
    }
}
