import React from 'react';

import HeaderSection from '../components/header/HeaderSection';
import FooterSection from '../components/footer/FooterSection';
import CartBody from '../components/body/CartBody';

export default class Home extends React.Component {
    render() {
        let items = this.props.items || [];
        return  <React.Fragment>
                    <HeaderSection />
                    <CartBody />
                    <FooterSection />
                </React.Fragment>
    }
}
