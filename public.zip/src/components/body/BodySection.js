import React from 'react';
import ContentLeft from './ContentLeft';
import ContentRight from './ContentRight';

export default class BodySection extends React.Component {
    
    render() {
        let items = this.props.items || [];
        return <div class="content">
                    <ContentLeft />
                    <ContentRight items={items} />
                </div>
    }
} 