import React from 'react';

export default class ProductList extends React.Component {
    
    render() {
        let items = this.props.items || [];
        return  <div class="content__right__list">
                    {
                    items.length > 0 && items.map((item, index) => {
                        return <div class="content__right__list__item">
                                <div><img width="160" alt="product" src={item.image} /></div>
                                <div class="content__right__list__item__name">{item.name}</div>
                                <div class="content__right__list__item__price">
                                <span class="--salePrice">&#8377;{item.price.actual}</span>
                                <span class="--listPrice">{item.price.display}</span>
                                <span class="--discount">{item.discount}% off</span>
                                </div>
                                <div class="content__right__list__item__btn"><span class="--btn">Add to Cart</span></div>
                            </div>
                    }) 
                    }
                </div>
    }
} 