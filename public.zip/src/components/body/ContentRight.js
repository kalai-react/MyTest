import React from 'react';
import SortSection from './SortSection';
import ProductList from './ProductList';

export default class ContentRight extends React.Component {
    
    render() {
        let items = this.props.items || [];
        return <div class="content__right">
                    <SortSection />
                    <ProductList items={items} />
                </div>
    }
} 