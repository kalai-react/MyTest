import React from 'react';

export default class CartBody extends React.Component {
    
    render() {
        return <div class="cartBody">
                    This cart page content...
                </div>
    }
} 