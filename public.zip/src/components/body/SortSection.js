import React from 'react';

export default class SortSection extends React.Component {
    
    render() {
        return  <div class="content__right__sort">
                    <span class="content__right__sort__label">Sort By</span>
                    <span class="content__right__sort__option --active">Price -- High Low</span>
                    <span class="content__right__sort__option">Price -- Low High</span>
                    <span class="content__right__sort__option">Discount</span>
                </div>
    }
} 