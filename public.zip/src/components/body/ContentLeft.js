import React from 'react';

export default class ContentLeft extends React.Component {
    
    render() {
        return  <div class="content__left">
                    <h3 class="content__left__h3">Filters</h3>
                    <div class="content__left__filter">
                        <span class="--start"></span>
                        <span class="--line"></span>
                        <span class="--end"></span>
                    </div>
                    <div>Price</div>
                    <div class="--applyBtn">Apply</div>
                </div>
    }
} 