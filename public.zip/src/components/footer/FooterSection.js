import React from 'react';

export default class FooterSection extends React.Component {
    render() {
        return <footer>
                    <div class="footer">@copyrigh</div>
                </footer>
    }
} 