import React from 'react';
import { Link } from "react-router-dom";

export default class HeaderSection extends React.Component {
    render() {
        return <header>
                <div class="header">
                    <div class="header__left">
                        <Link to="/"><i class="fa fa-star header__left__star"></i></Link>
                    </div>

                    <div class="header__right">
                        <i class="fa fa-search header__right__search"></i>
                        <span class="header__right__cart">
                        <Link to="/cart"><i class="fa fa-shopping-cart header__right__cart__icon"></i></Link>
                        <i class="header__right__cart__count">99</i>
                        </span>
                    </div>
                </div>
            </header>
    }
} 